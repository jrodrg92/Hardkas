import { Command } from "commander";
import { formatSompi, parseKasToSompi } from "@hardkas/core";
import { TxSimulator } from "@hardkas/simulator";
import { buildPaymentPlan, createMockUtxo } from "@hardkas/tx-builder";

const program = new Command();

program
  .name("hardkas")
  .description("Developer toolkit for Kaspa applications")
  .version("0.1.0");

program
  .command("init")
  .description("Create a new HardKAS project")
  .argument("[directory]", "Project directory", ".")
  .action(async (directory: string) => {
    console.log(`Initializing HardKAS project in ${directory}`);
    console.log("v0.1 scaffold command placeholder");
  });

program
  .command("dev")
  .description("Start local HardKAS development environment")
  .action(async () => {
    console.log("Starting HardKAS dev environment");
    console.log("v0.1 uses simulated localnet only");
  });

const tx = program.command("tx").description("Transaction commands");

tx.command("simulate")
  .description("Simulate a Kaspa payment transaction")
  .requiredOption("--to <address>", "Recipient address")
  .requiredOption("--amount <kas>", "Amount in KAS")
  .option("--from <address>", "Sender address", "kaspa:alice")
  .option("--fee-rate <sompiPerMass>", "Fee rate in sompi per mass", "1")
  .action(async (options: { to: string; amount: string; from: string; feeRate: string }) => {
    const amountSompi = parseKasToSompi(options.amount);
    const feeRateSompiPerMass = BigInt(options.feeRate);

    const plan = buildPaymentPlan({
      fromAddress: options.from,
      outputs: [{ address: options.to, amountSompi }],
      availableUtxos: [
        createMockUtxo({
          address: options.from,
          amountSompi: amountSompi + 100_000_000n,
          index: 0
        })
      ],
      feeRateSompiPerMass
    });

    const simulator = new TxSimulator();
    const result = await simulator.simulate([
      "build",
      "resolve-utxos",
      "estimate-mass",
      "estimate-fee",
      "validate-local"
    ]);

    if (!result.ok) {
      console.error("Simulation failed");
      console.error(JSON.stringify(result.events, null, 2));
      process.exitCode = 1;
      return;
    }

    console.log("Simulation OK");
    console.log("");
    console.log(`Inputs: ${plan.inputs.length}`);
    console.log(`Outputs: ${plan.outputs.length + (plan.change ? 1 : 0)}`);
    console.log(`Estimated mass: ${plan.estimatedMass}`);
    console.log(`Estimated fee: ${formatSompi(plan.estimatedFeeSompi)}`);

    if (plan.change) {
      console.log(`Change: ${formatSompi(plan.change.amountSompi)}`);
    }

    console.log("");
    console.log("Trace:");
    for (const event of result.events) {
      if (event.type === "phase.completed") {
        console.log(`✓ ${event.phase}`);
      }
    }
  });

program
  .command("wallet")
  .description("Wallet commands")
  .command("detect")
  .description("Detect installed Kaspa wallet providers")
  .action(async () => {
    console.log("Wallet detection placeholder");
    console.log("No browser wallet providers are available from the Node.js CLI context yet.");
  });

program
  .command("trace")
  .description("Trace commands")
  .argument("[txId]", "Transaction id")
  .action(async (txId?: string) => {
    console.log(`Trace placeholder${txId ? ` for ${txId}` : ""}`);
  });

program
  .command("replay")
  .description("Replay a saved HardKAS trace")
  .argument("<traceFile>", "Trace JSON file")
  .action(async (traceFile: string) => {
    console.log(`Replay placeholder for ${traceFile}`);
  });

await program.parseAsync(process.argv);
