import { z } from "zod";

export const kaspaNetworkIdSchema = z.enum([
  "mainnet",
  "testnet-10",
  "testnet-11",
  "testnet-12",
  "simnet",
  "devnet"
]);

export type KaspaNetworkId = z.infer<typeof kaspaNetworkIdSchema>;

export const hardkasConfigSchema = z.object({
  project: z.object({
    name: z.string().min(1),
    root: z.string().min(1)
  }),
  network: z.object({
    id: kaspaNetworkIdSchema,
    rpcUrl: z.string().url().optional()
  }),
  localnet: z
    .object({
      mode: z.enum(["simulated", "local-node"]).default("simulated"),
      dataDir: z.string().optional()
    })
    .default({ mode: "simulated" })
});

export type HardkasConfig = z.infer<typeof hardkasConfigSchema>;

export class HardkasError extends Error {
  readonly code: string;
  readonly cause?: unknown;

  constructor(code: string, message: string, options?: { cause?: unknown }) {
    super(message);
    this.name = "HardkasError";
    this.code = code;
    this.cause = options?.cause;
  }
}

export function parseHardkasConfig(input: unknown): HardkasConfig {
  const result = hardkasConfigSchema.safeParse(input);

  if (!result.success) {
    throw new HardkasError(
      "CONFIG_INVALID",
      result.error.issues.map((issue) => issue.message).join("; "),
      { cause: result.error }
    );
  }

  return result.data;
}

export function formatSompi(amountSompi: bigint): string {
  const kas = amountSompi / 100_000_000n;
  const fractional = amountSompi % 100_000_000n;
  return `${kas}.${fractional.toString().padStart(8, "0")} KAS`;
}

export function parseKasToSompi(input: string): bigint {
  const trimmed = input.trim();

  if (!/^\d+(\.\d{1,8})?$/.test(trimmed)) {
    throw new HardkasError("AMOUNT_INVALID", `Invalid KAS amount: ${input}`);
  }

  const [whole, fractional = ""] = trimmed.split(".");
  return BigInt(whole) * 100_000_000n + BigInt(fractional.padEnd(8, "0"));
}
