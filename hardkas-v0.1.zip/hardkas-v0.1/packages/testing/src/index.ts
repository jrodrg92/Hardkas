import { MockKaspaRpcClient } from "@hardkas/kaspa-rpc";
import { createMockUtxo } from "@hardkas/tx-builder";

export interface TestWallet {
  readonly name: string;
  readonly address: string;
}

export interface HardkasTestContext {
  readonly wallets: {
    readonly alice: TestWallet;
    readonly bob: TestWallet;
    readonly carol: TestWallet;
    readonly faucet: TestWallet;
  };
  readonly rpc: MockKaspaRpcClient;
  readonly faucet: {
    fund(address: string, amountSompi: bigint): Promise<void>;
  };
  reset(): Promise<void>;
}

export async function createHardkasTestContext(): Promise<HardkasTestContext> {
  const rpc = new MockKaspaRpcClient("simnet");

  const wallets = {
    alice: { name: "alice", address: "kaspa:alice" },
    bob: { name: "bob", address: "kaspa:bob" },
    carol: { name: "carol", address: "kaspa:carol" },
    faucet: { name: "faucet", address: "kaspa:faucet" }
  } as const;

  return {
    wallets,
    rpc,
    faucet: {
      async fund(address: string, amountSompi: bigint): Promise<void> {
        rpc.setUtxos(address, [
          createMockUtxo({
            address,
            amountSompi,
            index: 0
          })
        ]);
      }
    },
    async reset(): Promise<void> {
      rpc.setUtxos(wallets.alice.address, []);
      rpc.setUtxos(wallets.bob.address, []);
      rpc.setUtxos(wallets.carol.address, []);
    }
  };
}

export const hardkas = {
  localnet: createHardkasTestContext
};
