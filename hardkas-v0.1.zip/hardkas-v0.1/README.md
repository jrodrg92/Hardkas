# HardKAS

Developer toolkit for building, testing, simulating and debugging Kaspa applications.

HardKAS is designed for Kaspa-native development workflows:

- transaction building
- UTXO management
- transaction simulation
- wallet-connected signing
- local testing
- traces and replay
- future SilverScripts, vProgs and L2/Igra workflows

## Status

This is a v0.1 scaffold. It is intentionally small and focused.

The first goal is:

```bash
pnpm install
pnpm build
pnpm --filter @hardkas/cli hardkas tx simulate --to kaspa:example --amount 1
```

## Monorepo

```txt
packages/
  cli
  core
  kaspa-rpc
  tx-builder
  simulator
  wallet-adapter
  testing
  sdk
```

## Philosophy

HardKAS does not treat Kaspa L1 as Ethereum.

Kaspa L1 is not an EVM execution layer. HardKAS focuses on Kaspa-native transaction
workflows first, then adds extension points for SilverScripts, vProgs and L2 systems.
